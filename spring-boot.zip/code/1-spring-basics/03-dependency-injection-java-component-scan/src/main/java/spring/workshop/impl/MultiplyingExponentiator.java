package spring.workshop.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import spring.workshop.interfaces.Exponentiator;
import spring.workshop.interfaces.Multiplier;

import java.util.function.LongUnaryOperator;
import java.util.stream.LongStream;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

public class MultiplyingExponentiator implements Exponentiator {

    private Multiplier multiplier;

    public MultiplyingExponentiator(Multiplier multiplier) {
        this.multiplier = multiplier;
    }

    @Override
    public long pow(long base, int exponent) {
        System.out.println("Exponentiation by multiplying: " + base + " ^ " + exponent);

        return LongStream.iterate(base, LongUnaryOperator.identity())
                .limit(exponent)
                .reduce(1, (x, y) -> multiplier.multiply(x, y));
    }
}
