package spring.workshop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import spring.workshop.interfaces.Exponentiator;

public class Main {

    public static void main(String... args) {
        executeWith(createApplicationContext("example1.xml"));
        executeWith(createApplicationContext("example2.xml"));
        executeWith(createApplicationContext("example3.xml"));
    }

    private static void executeWith(ApplicationContext ctx) {
        long base = 3;
        int exponent = 4;

        Exponentiator service = ctx.getBean(Exponentiator.class);
        long result = service.pow(base, exponent);
        System.out.println("Computing with " + service.getClass());
        System.out.println("Result of " + base + " ^ " + exponent + ": " + result);
    }

    private static ApplicationContext createApplicationContext(String path) {
        return new ClassPathXmlApplicationContext(path);
    }

    /*
    private static ApplicationContext createApplicationContext(String path) {
        return new FileSystemXmlApplicationContext("./src/main/resources/" + path);
    }*/
}

