package spring.workshop.impl;

import spring.workshop.interfaces.Multiplier;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class DefaultMultiplier implements Multiplier {


    @Override
    public long multiply(long a, long b) {
        System.out.println("Default multiply: " + a + " * " + b);

        return a * b;
    }

}
