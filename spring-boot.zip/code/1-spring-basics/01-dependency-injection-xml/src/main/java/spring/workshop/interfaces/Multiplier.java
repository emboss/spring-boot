package spring.workshop.interfaces;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface Multiplier {

    long multiply(long a, long b);

}
