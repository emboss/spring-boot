package spring.workshop.impl;

import spring.workshop.interfaces.Adder;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class DefaultAdder implements Adder {

    @Override
    public long add(long a, long b) {
        System.out.println("Default add: " + a + " + " + b);

        return a + b;
    }
}
