package spring.workshop.interfaces;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface Adder {

    long add(long a, long b);
}
