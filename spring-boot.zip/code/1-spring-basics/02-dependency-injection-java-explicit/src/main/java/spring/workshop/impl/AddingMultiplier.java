package spring.workshop.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import spring.workshop.interfaces.Adder;
import spring.workshop.interfaces.Multiplier;

import java.util.function.Function;
import java.util.function.IntUnaryOperator;
import java.util.function.LongUnaryOperator;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class AddingMultiplier implements Multiplier {

    private Adder adder;

    public AddingMultiplier(Adder adder) {
        this.adder = adder;
    }

    @Override
    public long multiply(long a, long b) {
        System.out.println("Multiplying by adding: " + a + " * " + b);

        return LongStream.iterate(a, LongUnaryOperator.identity())
                .limit(b)
                .reduce(0, (x, y) -> adder.add(x, y));
    }

    public void setAdder(Adder adder) {
        this.adder = adder;
    }
}
