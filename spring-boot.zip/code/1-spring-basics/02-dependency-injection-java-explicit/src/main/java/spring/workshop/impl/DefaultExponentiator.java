package spring.workshop.impl;

import org.springframework.stereotype.Component;
import spring.workshop.interfaces.Exponentiator;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class DefaultExponentiator implements Exponentiator {

    @Override
    public long pow(long base, int exponent) {
        //ugly, but for the sake of the example...
        return (long)Math.pow(base, exponent);
    }

}
