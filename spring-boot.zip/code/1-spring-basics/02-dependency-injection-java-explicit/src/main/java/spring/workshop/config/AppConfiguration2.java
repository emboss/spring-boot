package spring.workshop.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import spring.workshop.impl.DefaultMultiplier;
import spring.workshop.impl.MultiplyingExponentiator;
import spring.workshop.interfaces.Exponentiator;
import spring.workshop.interfaces.Multiplier;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@Configuration
public class AppConfiguration2 {

    @Bean
    public Multiplier multiplier() {
        return new DefaultMultiplier();
    };

    @Bean
    public Exponentiator exponentiator() {
        return new MultiplyingExponentiator(multiplier());
    }

}
