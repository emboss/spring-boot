package spring.workshop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import spring.workshop.impl.DefaultExponentiator;
import spring.workshop.interfaces.Exponentiator;
import spring.workshop.interfaces.Multiplier;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@Configuration
public class AppConfiguration1 {

    @Bean
    public Exponentiator exponentiator() {
        return new DefaultExponentiator();
    }

}
