package spring.workshop.config;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import spring.workshop.impl.AddingMultiplier;
import spring.workshop.impl.DefaultAdder;
import spring.workshop.interfaces.Adder;
import spring.workshop.interfaces.Multiplier;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@Configuration
public class AppConfiguration {

    @Bean
    public Adder adder() {
        return new DefaultAdder();
    };

    @Bean
    public Multiplier multiplier() {
        return new AddingMultiplier(adder());
    }

    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    Adder prototypedAdder() {
        return new DefaultAdder();
    }

}
