package spring.workshop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import spring.workshop.config.AppConfiguration;
import spring.workshop.interfaces.Adder;
import spring.workshop.interfaces.Multiplier;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {

    public static void main(String... args) {
        IntStream.range(0, 2).forEach(i -> {
            System.out.println("Run #" + i);
            executeWith(createApplicationContext(AppConfiguration.class));
        });
    }

    private static void executeWith(ApplicationContext ctx) {
        System.out.println("Registered beans:");
        Stream.of(ctx.getBeanDefinitionNames()).forEach(
                name -> System.out.println(name)
        );
        System.out.println();

        IntStream.range(0, 5).forEach(i -> {
            Multiplier service = (Multiplier)ctx.getBean(Multiplier.class);
            System.out.println("Obtained multiplier: " + service.hashCode());
            Adder prototypedAdder = (Adder)ctx.getBean("prototypedAdder");
            System.out.println("Obtained prototyped adder: " + prototypedAdder.hashCode());
        });

    }

    private static ApplicationContext createApplicationContext(Class configurationClass) {
        return new AnnotationConfigApplicationContext(configurationClass);
    }
}

