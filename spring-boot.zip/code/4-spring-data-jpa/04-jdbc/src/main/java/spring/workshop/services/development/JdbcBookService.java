package spring.workshop.services.development;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import spring.workshop.models.Book;
import spring.workshop.models.JsonBook;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
public class JdbcBookService {

    private final JdbcTemplate template;

    public JdbcBookService(@Autowired DataSource dataSource) {
        this.template = new JdbcTemplate(dataSource);
    }

    public Optional<JsonBook> get(Long id) {
        return template.queryForObject(
            "select * from book where id = ?",
            new Object[] { id },
            this::resultSetToBook
        );
    }

    private Optional<JsonBook> resultSetToBook(ResultSet resultSet, int rowNum) {
      return Optional.ofNullable(resultSet).map(rs -> {
          try {
              JsonBook book = new JsonBook();
              book.id = rs.getLong("id");
              book.authorId = rs.getLong("author_id");
              book.title = rs.getString("title");
              book.yearPublished = rs.getInt("year_published");
              book.price = rs.getString("price");
              return book;
          } catch (SQLException ex) {
              throw new RuntimeException(ex);
          }
      });
    }
}
