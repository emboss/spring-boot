package spring.workshop.models;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class JsonBook {

    public Long id;

    public Long authorId;

    public String title;

    public Integer yearPublished;

    public String price;

}
