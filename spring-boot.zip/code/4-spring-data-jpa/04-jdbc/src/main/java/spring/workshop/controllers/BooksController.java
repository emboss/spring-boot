package spring.workshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import spring.workshop.models.Book;
import spring.workshop.models.JsonBook;
import spring.workshop.services.development.JdbcBookService;
import spring.workshop.services.spi.BookService;

import javax.persistence.EntityNotFoundException;
import java.util.Collection;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RestController
public class BooksController {

    @Autowired
    BookService bookService;

    @Autowired
    JdbcBookService jdbcBookService;

    @GetMapping("/books")
    public ResponseEntity<Collection<Book>> list() {
        return new ResponseEntity<>(
                bookService.list(),
                HttpStatus.OK
        );
    }

    @GetMapping("/books/{id}")
    public ResponseEntity<Book> show(@PathVariable Long id) {
        return new ResponseEntity<>(
                bookService.get(id).orElseThrow(EntityNotFoundException::new),
                HttpStatus.OK
        );
    }

    @GetMapping("/jsonBooks/{id}")
    public ResponseEntity<JsonBook> showJsonBook(@PathVariable Long id) {
        return new ResponseEntity<>(
            jdbcBookService.get(id).orElseThrow(EntityNotFoundException::new),
            HttpStatus.OK
        );
    }

    @PostMapping("/books")
    public ResponseEntity<Void> create(@RequestBody Book book) {
        Long id = bookService.add(book);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(
                UriComponentsBuilder.fromPath("books/{id}")
                .buildAndExpand(id).toUri()
        );

        return new ResponseEntity<>(headers, HttpStatus.CREATED);
    }

    @PutMapping("/books/{id}")
    public ResponseEntity<Book> update(@PathVariable Long id, @RequestBody Book book) {
        Book updated = bookService.update(id, book);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }

    @DeleteMapping("/books/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        bookService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
