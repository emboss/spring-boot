package spring.workshop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import spring.workshop.models.Book;
import spring.workshop.services.development.JpaBookService;

import java.util.Arrays;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class BooksTest {

    @Autowired
    private JpaBookService bookService;

    private Book newBook() {
        Book book = new Book();
        book.setAuthor("Haruki Murakami");
        book.setTitle("Kafka am Strand");
        book.setYearPublished(2006);
        book.setPrice("12.00");
        return book;
    }

    private Book newBook2() {
        Book book = new Book();
        book.setAuthor("Stephen King");
        book.setTitle("Es");
        book.setYearPublished(1990);
        book.setPrice("7.80");
        return book;
    }

    private Book invalidBook() {
        Book book = new Book();
        book.setAuthor("Martin Boßlet");
        book.setTitle("Sinn des Lebens");
        book.setYearPublished(2200);
        book.setPrice("42.00");
        return book;
    }

    @Test
    public void testTransaction() {
        Book b1 = newBook();
        Book b2 = newBook2();
        Book b3 = invalidBook();

        try {
            bookService.createBooks(Arrays.asList(b1, b2, b3));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        assertTrue(bookService.list().isEmpty());
    }

    @Test
    public void testNonTransactional() {
        Book b1 = newBook();
        Book b2 = newBook2();
        Book b3 = invalidBook();

        try {
            bookService.createBooksNonTransactional(Arrays.asList(b1, b2, b3));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        assertEquals(2, bookService.list().size());
    }

    @Test
    public void testProgrammaticTransaction() {
        Book b1 = newBook();
        Book b2 = newBook2();
        Book b3 = invalidBook();

        bookService.createBooksProgrammaticTransaction(Arrays.asList(b1, b2, b3));

        assertTrue(bookService.list().isEmpty());
    }

}
