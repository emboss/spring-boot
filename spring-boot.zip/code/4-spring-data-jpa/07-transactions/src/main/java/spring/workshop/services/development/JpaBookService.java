package spring.workshop.services.development;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import spring.workshop.models.Book;
import spring.workshop.models.repositories.BookRepository;
import spring.workshop.services.spi.BookService;

import javax.persistence.EntityNotFoundException;
import javax.validation.ConstraintViolationException;
import java.util.Collection;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
@Profile({"development", "test"})
public class JpaBookService implements BookService {

    @Autowired
    private BookRepository repo;

    @Autowired
    PlatformTransactionManager platformTransactionManager;

    @Override
    @Transactional(readOnly = true)
    public Collection<Book> list() {
        return repo.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Book> get(Long id) {
        return repo.findById(id);
    }

    @Override
    @Transactional
    public Long add(Book book) {
        return repo.saveAndFlush(book).getId();
    }

    @Override
    @Transactional
    public Book update(Long id, Book updated) {
        return get(id)
            .map(book -> repo.saveAndFlush(updateWith(book, updated)))
            .orElseThrow(EntityNotFoundException::new);
    }

    @Override
    @Transactional
    public Book delete(Long id) {
        return get(id)
            .map(book -> {
                repo.delete(book);
                return book;
            }).orElseThrow(EntityNotFoundException::new);
    }

    @Transactional()
    public void createBooks(Collection<Book> books) {
        books.forEach(this::add);
    }

    public void createBooksNonTransactional(Collection<Book> books) {
        books.forEach(this::add);
    }

    public void createBooksProgrammaticTransaction(Collection<Book> books) {
        TransactionTemplate t = new TransactionTemplate(platformTransactionManager);
        t.execute(transactionStatus -> {
           try {
               books.forEach(this::add);
           } catch (ConstraintViolationException ex) {
               System.out.println("Caught ConstraintViolationException: " + ex);
               transactionStatus.setRollbackOnly();
           }
           return null;
        });
    }

    private Book updateWith(Book current, Book updated) {
        current.setAuthor(updated.getAuthor());
        current.setTitle(updated.getTitle());
        current.setYearPublished(updated.getYearPublished());
        current.setPrice(updated.getPrice());
        return current;
    }
}
