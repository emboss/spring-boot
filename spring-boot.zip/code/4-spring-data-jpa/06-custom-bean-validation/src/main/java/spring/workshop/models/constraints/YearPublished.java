package spring.workshop.models.constraints;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.time.LocalDate;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Target({ FIELD, METHOD, PARAMETER, ANNOTATION_TYPE })
@Retention(RUNTIME)
@Constraint(validatedBy = YearPublished.YearPublishedValidator.class)
public @interface YearPublished {

    String message() default "{spring.workshop.YearPublished.message}";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    class YearPublishedValidator implements ConstraintValidator<YearPublished, Integer> {
        @Override
        public void initialize(YearPublished constraintAnnotation) {
            // no setup needed
        }

        /**
         * The year must be >= 1900 and <= the current year. Null is considered valid
         */
        @Override
        public boolean isValid(Integer value, ConstraintValidatorContext context) {
            if (value == null) return true;

            return value >= 1900 && isPast(value);
        }

        private boolean isPast(Integer value) {
            return value <= LocalDate.now().getYear();
        }
    }
}
