package spring.workshop.models;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.Date;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Entity
@Table(indexes = {
    @Index(columnList = "author"),
    @Index(columnList = "title")
})
public class Book {

    public Book() {}

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotBlank
    private String author;

    @NotBlank
    private String title;

    @Digits(integer=4, fraction = 0)
    @Min(1900)
    @Max(2100)
    private Integer yearPublished;


    @Pattern(regexp = "\\d+\\.\\d{2}")
    private String price;

    @CreationTimestamp
    private Date createdAt;

    @UpdateTimestamp
    private Date updatedAt;

    public Long getId() {
        return id;
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public Integer getYearPublished() {
        return yearPublished;
    }

    public String getPrice() {
        return price;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setYearPublished(Integer yearPublished) {
        this.yearPublished = yearPublished;
    }

    public void setPrice(String price) {
        this.price = price;
    }

}
