package spring.workshop.models.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import spring.workshop.models.Book;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface BookRepository extends JpaRepository<Book, Long> {


}
