package spring.workshop.services.development;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import spring.workshop.models.Book;
import spring.workshop.models.repositories.BookRepository;
import spring.workshop.services.spi.BookService;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import javax.transaction.Transactional;
import java.util.Collection;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
@Profile({"development", "test"})
public class JpaBookService implements BookService {

    @Autowired
    private BookRepository repo;

    @Override
    @Transactional
    public Collection<Book> list() {
        return repo.findAll();
    }

    @Override
    @Transactional
    public Optional<Book> get(Long id) {
        return repo.findById(id);
    }

    @Override
    @Transactional
    public Long add(Book book) {
        return repo.saveAndFlush(book).getId();
    }

    @Override
    @Transactional
    public Book update(Long id, Book updated) {
        return get(id)
            .map(book -> repo.saveAndFlush(updateWith(book, updated)))
            .orElseThrow(EntityNotFoundException::new);
    }

    @Override
    @Transactional
    public Book delete(Long id) {
        return get(id)
            .map(book -> {
                repo.delete(book);
                return book;
            }).orElseThrow(EntityNotFoundException::new);
    }

    private Book updateWith(Book current, Book updated) {
        current.setAuthor(updated.getAuthor());
        current.setTitle(updated.getTitle());
        current.setYearPublished(updated.getYearPublished());
        current.setPrice(updated.getPrice());
        return current;
    }
}
