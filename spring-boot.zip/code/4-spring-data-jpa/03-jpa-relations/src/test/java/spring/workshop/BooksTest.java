package spring.workshop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import spring.workshop.models.Author;
import spring.workshop.models.Book;

import static org.junit.Assert.assertEquals;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class BooksTest {

    @Autowired
    private TestRestTemplate restTemplate;

    private Author newAuthor() {
        Author author = new Author();
        author.setFirstName("Haruki");
        author.setLastName("Murakami");
        return author;
    }

    private Book newBook(Author author) {
        Book book = new Book();
        book.setAuthor(author);
        book.setTitle("Kafka am Strand");
        book.setYearPublished(2006);
        book.setPrice("12.00");
        return book;
    }

    @Test
    public void createBook() throws Exception {
        Author author = newAuthor();
        Book newBook = newBook(author);
        ResponseEntity<Void> response = restTemplate.postForEntity("/books", newBook, Void.class);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("books/1", response.getHeaders().getLocation().toString());
        ResponseEntity<Book> bookResponse = restTemplate.getForEntity("/books/1", Book.class);
        assertEquals(HttpStatus.OK, bookResponse.getStatusCode());
        Book created = bookResponse.getBody();
        assertEquals(1l, (long)created.getId());
        assertEquals(newBook.getTitle(), created.getTitle());
    }

    @Test
    public void createBookWithExistingAuthor() throws Exception {
        Author author = newAuthor();

        restTemplate.postForEntity("/authors", author, Void.class);
        ResponseEntity<Author> authorResponse = restTemplate.getForEntity("/authors/1", Author.class);
        assertEquals(HttpStatus.OK, authorResponse.getStatusCode());
        Author createdAuthor = authorResponse.getBody();

        Book newBook = newBook(createdAuthor);
        ResponseEntity<Void> response = restTemplate.postForEntity("/books", newBook, Void.class);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("books/1", response.getHeaders().getLocation().toString());
        ResponseEntity<Book> bookResponse = restTemplate.getForEntity("/books/1", Book.class);
        assertEquals(HttpStatus.OK, bookResponse.getStatusCode());
        Book created = bookResponse.getBody();
        assertEquals(1l, (long)created.getId());
        assertEquals(newBook.getTitle(), created.getTitle());
        Author bookAuthor = created.getAuthor();
        assertEquals(author.getFirstName(), bookAuthor.getFirstName());
        assertEquals(author.getLastName(), bookAuthor.getLastName());
    }

}
