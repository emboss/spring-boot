package spring.workshop.services.spi;

import spring.workshop.models.Author;

import java.util.Collection;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface AuthorService {

    Collection<Author> list();
    Optional<Author> get(Long id);
    Long add(Author author);
    Author update(Long id, Author updated);
    Author delete(Long id);

}
