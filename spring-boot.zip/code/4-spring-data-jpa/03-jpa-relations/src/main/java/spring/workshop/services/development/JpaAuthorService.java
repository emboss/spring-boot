package spring.workshop.services.development;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import spring.workshop.models.Author;
import spring.workshop.models.repositories.AuthorRepository;
import spring.workshop.services.spi.AuthorService;

import javax.persistence.EntityNotFoundException;
import java.util.Collection;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
@Profile({"development", "test"})
public class JpaAuthorService implements AuthorService {

    @Autowired
    private AuthorRepository repo;

    @Override
    public Collection<Author> list() {
        return repo.findAll();
    }

    @Override
    public Optional<Author> get(Long id) {
        return repo.findById(id);
    }

    @Override
    public Long add(Author author) {
        return repo.saveAndFlush(author).getId();
    }

    @Override
    public Author update(Long id, Author updated) {
        return get(id)
            .map(author -> repo.saveAndFlush(updateWith(author, updated)))
            .orElseThrow(EntityNotFoundException::new);
    }

    @Override
    public Author delete(Long id) {
        return get(id)
            .map(author -> {
                repo.delete(author);
                return author;
            }).orElseThrow(EntityNotFoundException::new);
    }

    private Author updateWith(Author current, Author updated) {
        current.setFirstName(updated.getFirstName());
        current.setLastName(updated.getLastName());
        return current;
    }
}
