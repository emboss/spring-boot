package spring.workshop.models;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Entity
@Table(indexes = {
    @Index(columnList = "title")
})
@SequenceGenerator(name = "book_seq", sequenceName = "book_seq", initialValue = 1, allocationSize = 1)
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "book_seq")
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Author author;

    private String title;

    private Integer yearPublished;

    private String price;

    @CreationTimestamp
    private Date createdAt;

    @UpdateTimestamp
    private Date updatedAt;

    public Long getId() {
        return id;
    }

    public Author getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public Integer getYearPublished() {
        return yearPublished;
    }

    public String getPrice() {
        return price;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setYearPublished(Integer yearPublished) {
        this.yearPublished = yearPublished;
    }

    public void setPrice(String price) {
        this.price = price;
    }

}
