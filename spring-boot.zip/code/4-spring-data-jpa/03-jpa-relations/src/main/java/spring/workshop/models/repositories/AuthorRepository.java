package spring.workshop.models.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import spring.workshop.models.Author;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface AuthorRepository extends JpaRepository<Author, Long> {

}


