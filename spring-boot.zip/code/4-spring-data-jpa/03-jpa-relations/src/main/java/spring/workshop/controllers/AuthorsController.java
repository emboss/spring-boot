package spring.workshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import spring.workshop.models.Author;
import spring.workshop.services.spi.AuthorService;

import javax.persistence.EntityNotFoundException;
import java.util.Collection;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RestController
public class AuthorsController {

    @Autowired
    AuthorService authorService;

    @GetMapping("/authors")
    public ResponseEntity<Collection<Author>> list() {
        return new ResponseEntity<>(
            authorService.list(),
            HttpStatus.OK
        );
    }

    @GetMapping("/authors/{id}")
    public ResponseEntity<Author> show(@PathVariable Long id) {
        return new ResponseEntity<>(
            authorService.get(id).orElseThrow(EntityNotFoundException::new),
            HttpStatus.OK
        );
    }

    @PostMapping("/authors")
    public ResponseEntity<Void> create(@RequestBody Author author) {
        Long id = authorService.add(author);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(
            UriComponentsBuilder.fromPath("authors/{id}")
                .buildAndExpand(id).toUri()
        );

        return new ResponseEntity<>(headers, HttpStatus.CREATED);
    }

    @PutMapping("/authors/{id}")
    public ResponseEntity<Author> update(@PathVariable Long id, @RequestBody Author author) {
        Author updated = authorService.update(id, author);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }

    @DeleteMapping("/authors/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        authorService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
