package spring.workshop.services.development;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import spring.workshop.models.Book;
import spring.workshop.services.spi.BookService;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import javax.transaction.Transactional;
import java.util.Collection;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
@Profile({"development", "test"})
public class JpaBookService implements BookService {

    @PersistenceContext
    private EntityManager em;

    @Override
    @Transactional
    public Collection<Book> list() {
        CriteriaQuery<Book> cq = em.getCriteriaBuilder().createQuery(Book.class);
        cq.select(cq.from(Book.class));
        return em.createQuery(cq).getResultList();
    }

    @Override
    @Transactional
    public Optional<Book> get(Long id) {
        return Optional.ofNullable(em.find(Book.class, id));
    }

    @Override
    @Transactional
    public Long add(Book book) {
        em.persist(book);
        return book.getId();
    }

    @Override
    @Transactional
    public Book update(Long id, Book updated) {
        return get(id)
            .map(book -> updateWith(book, updated))
            .orElseThrow(EntityNotFoundException::new);
    }

    @Override
    @Transactional
    public Book delete(Long id) {
        Book book = em.find(Book.class, id);
        em.remove(book);
        return book;
    }

    private Book updateWith(Book current, Book updated) {
        current.setAuthor(updated.getAuthor());
        current.setTitle(updated.getTitle());
        current.setYearPublished(updated.getYearPublished());
        current.setPrice(updated.getPrice());
        em.merge(current);
        return current;
    }
}
