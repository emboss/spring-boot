package spring.workshop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import spring.workshop.models.Book;

import static org.junit.Assert.assertEquals;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class BooksTest {

    @Autowired
    private TestRestTemplate restTemplate;

    private Book newBook() {
        Book book = new Book();
        book.author = "Haruki Murakami";
        book.title = "Kafka am Strand";
        book.yearPublished = 2006;
        book.price = "12.00";
        return book;
    }

    @Test
    public void createBook() throws Exception {
        Book newBook = newBook();
        ResponseEntity<Void> response = restTemplate.postForEntity("/books", newBook, Void.class);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("books/1", response.getHeaders().getLocation().toString());

        ResponseEntity<Book> bookResponse = restTemplate.getForEntity("/books/1", Book.class);
        assertEquals(HttpStatus.OK, bookResponse.getStatusCode());
        Book created = bookResponse.getBody();
        assertEquals(1l, (long)created.id);
        assertEquals(newBook.title, created.title);
    }

}
