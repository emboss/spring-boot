package spring.workshop.services.spi;

import spring.workshop.models.Book;

import java.util.Collection;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface BookService {

    Collection<Book> list();
    Optional<Book> get(Long id);
    Long add(Book book);
    Book update(Long id, Book updated);
    Book delete(Long id);

}
