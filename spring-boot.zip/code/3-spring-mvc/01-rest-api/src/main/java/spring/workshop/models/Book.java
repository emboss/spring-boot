package spring.workshop.models;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class Book {

    public Long id;
    public String author;
    public String title;
    public Integer yearPublished;
    public String price;

}
