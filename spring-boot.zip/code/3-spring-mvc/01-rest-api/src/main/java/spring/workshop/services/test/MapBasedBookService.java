package spring.workshop.services.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import spring.workshop.models.Book;
import spring.workshop.services.spi.BookService;
import spring.workshop.services.spi.SequenceGenerator;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
@Profile("test")
public class MapBasedBookService implements BookService {

    @Autowired
    private Map<Long, Book> bookMap;

    @Autowired
    private SequenceGenerator sequenceGenerator;

    public Collection<Book> list() {
        return bookMap.values();
    }

    public Optional<Book> get(Long id) {
        return Optional.ofNullable(bookMap.get(id));
    }

    public Long add(Book book) {
        Long id = sequenceGenerator.createId();
        book.id = id;
        bookMap.put(id, book);
        return id;
    }

    public Book update(Long id, Book updated) {
        updated.id = id;
        bookMap.put(id, updated);
        return updated;
    }

    public Book delete(Long id) {
        return bookMap.remove(id);
    }

}
