package spring.workshop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import spring.workshop.models.Book;
import spring.workshop.services.spi.SequenceGenerator;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@Configuration
@Profile("test")
public class TestConfiguration {

    @Bean
    public Map<Long, Book> bookMap() {
        return new ConcurrentHashMap<>();
    }

    @Bean
    public SequenceGenerator sequenceGenerator() {
        return new SequenceGenerator() {

            private long id = 1;

            @Override
            public Long createId() {
                return id++;
            }
        };
    }





}
