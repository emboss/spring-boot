package spring.workshop.services.spi;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface SequenceGenerator {

    Long createId();

}
