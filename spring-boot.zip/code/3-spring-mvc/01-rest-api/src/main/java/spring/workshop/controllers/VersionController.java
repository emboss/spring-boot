package spring.workshop.controllers;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersionController {

    @Value("${workshop.version}")
    private String version;

    @GetMapping("/version")
    public ResponseEntity<String> version() {
        return ResponseEntity.ok(version);
    }
}
