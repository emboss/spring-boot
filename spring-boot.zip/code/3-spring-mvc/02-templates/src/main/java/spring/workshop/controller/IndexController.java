package spring.workshop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Controller
public class IndexController {

    @Autowired
    private ResourceLoader loader;

    @GetMapping(path = "/")
    public String index(Model model) {
        model.addAttribute("banner", "Hello World!");
        return "index";
    }

}
