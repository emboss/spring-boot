insert into book(id, author, title, year_published, price, created_at, updated_at)
 values (1, 'Haruki Murakami', 'IQ84', 2010, '12.00', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
