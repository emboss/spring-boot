package workshop.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.ParallelFlux;
import reactor.core.scheduler.Schedulers;
import workshop.models.db.repositories.AsyncUserRepository;
import workshop.models.json.Tick;

import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Controller
public class IndexController {

    @Autowired
    private AsyncUserRepository repo;

    @GetMapping("/")
    public String index(Model model) {
        Mono<String> users = repo.getAll()
            .map(user -> user.getFirstName() + " " + user.getLastName())
            .collect(Collectors.joining(", "));

        Mono<String> title = Mono.just("Real-time clock powered by SSE");

        model.addAttribute("title", title);
        model.addAttribute("users", users);

        return "index";
    }

}
