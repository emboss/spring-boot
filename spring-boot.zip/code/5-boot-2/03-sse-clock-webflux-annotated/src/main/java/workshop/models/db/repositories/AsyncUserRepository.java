package workshop.models.db.repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import workshop.models.db.User;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
public class AsyncUserRepository {

    @Autowired
    private UserRepository repo;

    @Autowired
    @Qualifier("jdbcScheduler")
    private Scheduler scheduler;

    public Flux<User> getAll() {
        return asyncFlux(
            () -> repo.findAll()
        );
    }

    public Mono<Optional<User>> getById(Long id) {
        return async(
            () -> repo.findById(id)
        );
    }

    private <T> Mono<T> async(Callable<T> callable) {
        return Mono.fromCallable(callable).publishOn(scheduler).log();
    }

    private <T> Flux<T> asyncFlux(Callable<? extends List<T>> callable) {
        return async(callable).flatMapMany(Flux::fromIterable);
    }


}
