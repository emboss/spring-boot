insert into user (id, first_name, last_name) values (1, 'Martin', 'Boßlet');
insert into user (id, first_name, last_name) values (2, 'John', 'Doe');