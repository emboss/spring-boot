package workshop.models;

import org.springframework.data.r2dbc.repository.R2dbcRepository;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public interface UserRepository extends R2dbcRepository<User, Long> {

    //User findByEmailAndFirstName(String email, String firstName);

}
