package workshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import workshop.models.UserRepository;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Controller
public class WebController {

    @Autowired
    private UserRepository repo;

    @GetMapping("/")
    public String homePage(Model model) {
        model.addAttribute("title", "Kotlin-Schulung - Spring Boot Web App");
        model.addAttribute("author", "Martin Boßlet");

        return "homePage";
    }

    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", repo.findAll());

        return "users";
    }
}
