package workshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import workshop.models.User;
import workshop.services.UserService;

import java.util.List;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RestController
@RequestMapping("/api/users")
public class ApiController {

    @Autowired
    private UserService service;

    // curl -v localhost:8080/api/users
    @GetMapping("")
     public Flux<User> list() {
        return service.list();
    }

    // curl -v localhost:8080/api/users/1
    @GetMapping("/{id}")
    public Mono<ResponseEntity<User>> show(@PathVariable Long id) {
        return service.findById(id)
            .map(ResponseEntity::ok)
            .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    // curl -v -X POST -H "Content-Type: application/json" -d '{"firstName":"Max","lastName":"Müller","email":"max@example.org","age":42}' localhost:8080/api/users
    @PostMapping("")
    public Mono<ResponseEntity<User>> create(@RequestBody Mono<User> user) {
        return service.create(user).map(persisted ->
            ResponseEntity.created(
                UriComponentsBuilder.fromPath("users/{id}")
                    .buildAndExpand(persisted.getId()).toUri()
            ).body(persisted)
        );

    }

    // curl -v -X PUT -H "Content-Type: application/json" -d '{"firstName":"Max","lastName":"Schmidt","email":"max@example.org","age":42}' localhost:8080/api/users/2
    @PutMapping("/{id}")
    public Mono<ResponseEntity<User>> update(@PathVariable Long id, @RequestBody Mono<User> user) {
        return service.update(id, user)
            .map(it -> ResponseEntity.ok(it))
            .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    // curl -v -X DELETE localhost:8080/api/users/2
    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<User>> delete(@PathVariable Long id) {
        return service.delete(id).map(nil -> new ResponseEntity(HttpStatus.OK));
    }
}
