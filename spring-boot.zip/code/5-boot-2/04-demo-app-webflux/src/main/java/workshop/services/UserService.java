package workshop.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import workshop.models.User;
import workshop.models.UserRepository;

import java.util.List;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    public Flux<User> list() {
        return repo.findAll();
    }

    public Mono<User> findById(Long id)  {
        return repo.findById(id);
    }

    public Mono<User> create(Mono<User> userMono) {
        return userMono.flatMap(repo::save);
    }

    public Mono<User> update(Long id, Mono<User> updateMono) {
        return repo.findById(id).flatMap(
            it -> updateMono.flatMap(update -> repo.save(updateWith(it, update)))
        );
    }

    public Mono<Void> delete(Long id) {
        return repo.deleteById(id);
    }

    private User updateWith(User it, User other) {
        it.setFirstName(other.getFirstName());
        it.setLastName(other.getLastName());
        it.setEmail(other.getEmail());
        it.setAge(other.getAge());
        return it;
    }
}
