package workshop;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class Main {

    public static void main(String... args) throws Exception {
        sample01();
    }

    private static void sample01() {
        Mono.just("This is sample01")
        .log()
        .subscribe(System.out::println);
    }

    private static void sample02() {
        Flux.just("This", "is", "sample", "02")
        .log();
        //.subscribe(System.out::println);
    }

    private static void sample03() throws Exception {
        System.out.println("Start on thread " + Thread.currentThread());

        Flux.range(0, 10)
        .log()
        .flatMap(i -> {
            Mono<Integer> monoInt = Mono.fromCallable(() -> {
                try {
                    System.out.println("Waiting on thread " + Thread.currentThread());
                    Thread.sleep(500);
                    return i * 2;
                } catch (Exception ex) { throw new RuntimeException(ex); }
            }).publishOn(Schedulers.elastic());
            return monoInt;
        })
        .toStream()
        .forEach(i -> System.out.println("Received i " + i + " on thread " + Thread.currentThread()));

        System.out.println("Done on thread " + Thread.currentThread());
        //Thread.sleep(2000);
    }

    // Flux.interval publishes on parallel scheduler
    private static void sample04() throws Exception {
        Flux.interval(Duration.ofSeconds(1))
        .log()
        .map(i -> {
            System.out.println("Map is on thread: " + Thread.currentThread().getName());
            return i * i;
        })
        .take(10)
        .doOnNext(s -> System.out.println("On next " +s))
        .subscribe(s -> System.out.println("Received " + s));

        System.out.println("I'm here on thread " + Thread.currentThread());
        Thread.sleep(3000);
    }

    // Flux.range publishes and subscribes all on main thread
    private static void sample05() {
        Flux.range(0,5)
        .log()
        .map(i -> {
            try {
                System.out.println("" + i + " on thread " + Thread.currentThread().getName());
                Thread.sleep(1000);
                return Integer.valueOf(i * i);
            } catch (InterruptedException ex) { throw new RuntimeException(ex); }
        }).subscribe(i -> {
            System.out.println("Received " + i + " on " + Thread.currentThread().getName());
        });


    }

    /* SubscribeOn determines where the subscription starts, publishOn may switch
       the context - position-dependent!
     */
    private static void sample06() {
        Flux.range(0,5)
        .log()
        //.publishOn(Schedulers.immediate())
        .map(i -> {
            System.out.println("" + i + " before publishOn " + Thread.currentThread().getName());
            return i;
        })
        //.publishOn(Schedulers.immediate())
        .map(i -> {
            try {
                System.out.println("" + i + " after publishOn on thread " + Thread.currentThread().getName());
                Thread.sleep(1000);
                return Integer.valueOf(i * i);
            } catch (InterruptedException ex) { throw new RuntimeException(ex); }
        })
        .subscribeOn(Schedulers.immediate())
        .toStream()
        .forEach(i -> {
            System.out.println("Received " + i + " on " + Thread.currentThread().getName());
        });
    }

    /* First map is on main, then publishOn moves execution to a separate
     * thread for each Mono. Finally, the values are received back on the
     * main thread (no subscribeOn!)
     * => The execution takes roughly a second (= max of waiting per thread)
     */
    private static void sample07() throws Exception {
        Flux.range(0,10)
            .log()
            .map(i -> {
                System.out.println("" + i + " before publishOn " + Thread.currentThread().getName());
                return i;
            })
            .flatMap(i -> Mono.fromCallable(() -> {
                try {
                    System.out.println("" + i + " after publishOn on thread " + Thread.currentThread().getName());
                    Thread.sleep(1000);
                    return Integer.valueOf(i * i);
                } catch (InterruptedException ex) { throw new RuntimeException(ex); }
            }))//.publishOn(Schedulers.elastic()))
            .subscribeOn(Schedulers.elastic())
            .subscribe(i -> {
                System.out.println("Received " + i + " on " + Thread.currentThread().getName());
            });

        System.out.println("Done main thread");
        Thread.sleep(3000);
    }

    /* Similar result to the above. First map is on main, but then
     * subscription for each Mono is moved to elastic Scheduler.
     * The final forEach is back on the main thread
     * => The execution takes roughly a second (= max of waiting per thread)
     */
    private static void sample08() {
        Flux.range(0,10)
            .log()
            .map(i -> {
                System.out.println("" + i + " before publishOn " + Thread.currentThread().getName());
                return i;
            })
            .flatMap(i -> Mono.fromCallable(() -> {
                try {
                    System.out.println("" + i + " after publishOn on thread " + Thread.currentThread().getName());
                    Thread.sleep(1000);
                    return Integer.valueOf(i * i);
                } catch (InterruptedException ex) { throw new RuntimeException(ex); }
            }).subscribeOn(Schedulers.elastic()))
            .toStream()
            .forEach(i -> {
                System.out.println("Received " + i + " on " + Thread.currentThread().getName());
            });
    }

    /* The huge difference is that the overall Flux is subscribed on the elastic scheduler.
     * The work is thus not fanned out, and we have to wait for each Mono in sequence.
     * DoOnNext stays on the elastic thread, but the final forEach is back on main.
     * => The execution time is roughly 10 seconds
     */
    private static void sample09() {
        Flux.range(0,10)
            .log()
            .map(i -> {
                System.out.println("" + i + " before publishOn " + Thread.currentThread().getName());
                return i;
            })
            .flatMap(i -> Mono.fromCallable(() -> {
                try {
                    System.out.println("" + i + " after publishOn on thread " + Thread.currentThread().getName());
                    Thread.sleep(500);
                    System.out.println("" + i + " done waiting on thread " + Thread.currentThread().getName());
                    return Integer.valueOf(i * i);
                } catch (InterruptedException ex) { throw new RuntimeException(ex); }
            }).subscribeOn(Schedulers.elastic()))
            .doOnNext(i -> {
                System.out.println("Received i on thread " + Thread.currentThread().getName());
            }).toStream()
            .forEach(i -> {
                System.out.println("Finally received " + i + " on " + Thread.currentThread().getName());
            });
    }

    private static void sample10() {
        Scheduler myScheduler = Schedulers.newParallel("my-parallel");

        Flux.just("a", "b", "c")
            .log()
            .map(s -> {
                System.out.println(s + " first map " + Thread.currentThread().getName());
                return s;
            })
            .publishOn(myScheduler)
            .map(s -> {
                System.out.println(s + " second map " + Thread.currentThread().getName());
                return s;
            })
            .publishOn(myScheduler)
            .map(s -> {
                System.out.println(s + " third map " + Thread.currentThread().getName());
                return s;
            })
            .subscribeOn(Schedulers.newElastic("Martin's workers"))
            .doOnNext(s -> {
                System.out.println(s + " received on " + Thread.currentThread().getName());
            }).toStream().forEach(s -> {
                System.out.println("Finally received " + s + " on " + Thread.currentThread().getName());
            });
    }


}
