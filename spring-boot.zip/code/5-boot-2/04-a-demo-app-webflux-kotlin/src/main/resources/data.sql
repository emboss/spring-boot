insert into user(id, first_name, last_name, email, age)
 values (1, 'Martin', 'Boßlet', 'martin.bosslet@gmail.com', 39);
