package workshop.services

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import workshop.models.User
import workshop.models.UserRepository
import java.util.*

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Service
class UserService(@Autowired val repo: UserRepository) {

    fun list(): Flux<User> {
        return repo.findAll()
    }

    fun findById(id: Long): Mono<User> {
        return repo.findById(id)
    }

    fun create(user: Mono<User>): Mono<User> {
        return user.flatMap { repo.save(it) }
    }

    fun update(id: Long, updateMono: Mono<User>): Mono<User> {
        return repo.findById(id).flatMap {
            updateMono.flatMap { update -> repo.save(it.updateWith(update)) }
        }
    }

    fun delete(id: Long): Mono<Void> {
        return repo.deleteById(id)
    }

    private fun User.updateWith(other: User): User {
        this.firstName = other.firstName
        this.lastName = other.lastName
        this.email = other.email
        this.age = other.age
        return this
    }
}