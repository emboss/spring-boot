package workshop.controllers

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.ui.set
import org.springframework.web.bind.annotation.GetMapping
import workshop.models.UserRepository

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@Controller
class WebController(@Autowired val repo: UserRepository) {



    @GetMapping("/")
    fun homePage(model: Model): String {
        model["title"] = "Kotlin Workshop - Spring Boot Web App"
        model["author"] = "Martin Boßlet"
        return "homePage"
    }

    @GetMapping("/users")
    fun users(model: Model): String {
        model["users"] = repo.findAll()
        return "users"
    }

}