package workshop.models

import org.springframework.data.annotation.Id

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
class User(
    @Id
    var id: Long? = null,
    var firstName: String,
    var lastName: String,
    var email: String,
    var age: Int
)