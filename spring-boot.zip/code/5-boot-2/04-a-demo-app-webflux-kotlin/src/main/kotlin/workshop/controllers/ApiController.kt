package workshop.controllers

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.util.UriComponentsBuilder
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono
import workshop.models.User
import workshop.services.UserService
import java.util.*

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@RestController
@RequestMapping("/api/users")
class ApiController(@Autowired val service: UserService) {

    // curl -v localhost:8080/api/users
    @GetMapping("")
    fun list(): Flux<User> {
        return service.list()
    }

    // curl -v localhost:8080/api/users/1
    @GetMapping("/{id}")
    fun show(@PathVariable id: Long): Mono<ResponseEntity<User>> {
        return service.findById(id)
            .map { ResponseEntity.ok(it) }
            .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()))
    }

    // curl -v -X POST -H "Content-Type: application/json" -d '{"firstName":"Max","lastName":"Müller","email":"max@example.org","age":42}' localhost:8080/api/users
    @PostMapping("")
    fun create(@RequestBody user: Mono<User>): Mono<ResponseEntity<User>> {
        return service.create(user).map { persisted ->
            ResponseEntity.created(
                UriComponentsBuilder.fromPath("users/{id}")
                .buildAndExpand(persisted.id!!).toUri()
            ).body(persisted)
        }
    }

    // curl -v -X PUT -H "Content-Type: application/json" -d '{"firstName":"Max","lastName":"Schmidt","email":"max@example.org","age":42}' localhost:8080/api/users/2
    @PutMapping("/{id}")
    fun update(@PathVariable id: Long, @RequestBody user: Mono<User>): Mono<ResponseEntity<User>> {
        return service.update(id, user)
            .map { ResponseEntity.ok(it) }
            .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()))
    }

    // curl -v -X DELETE localhost:8080/api/users/2
    @DeleteMapping("/{id}")
    fun delete(@PathVariable id: Long): Mono<ResponseEntity<User>> {
        return service.delete(id).map { ResponseEntity<User>(HttpStatus.OK) }
    }

}