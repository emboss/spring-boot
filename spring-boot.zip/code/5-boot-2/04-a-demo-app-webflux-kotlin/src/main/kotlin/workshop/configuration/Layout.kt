package workshop.configuration

import java.io.IOException
import com.samskivert.mustache.Mustache
import com.samskivert.mustache.Template
import org.springframework.web.bind.annotation.ModelAttribute
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.ControllerAdvice
import java.io.Writer


/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@ControllerAdvice
class LayoutAdvice @Autowired
constructor(private val compiler: Mustache.Compiler) {

    @ModelAttribute("layout")
    fun layout(model: Map<String, Any>): Mustache.Lambda {
        return Layout(compiler)
    }
}

internal class Layout(private val compiler: Mustache.Compiler) : Mustache.Lambda {

    lateinit var body: String

    @Throws(IOException::class)
    override fun execute(frag: Template.Fragment, out: Writer) {
        body = frag.execute()
        compiler.compile("{{>layout}}").execute(frag.context(), out)
    }

}

