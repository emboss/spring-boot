package workshop.models

import org.springframework.data.r2dbc.repository.R2dbcRepository

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

interface UserRepository : R2dbcRepository<User, Long> {

}