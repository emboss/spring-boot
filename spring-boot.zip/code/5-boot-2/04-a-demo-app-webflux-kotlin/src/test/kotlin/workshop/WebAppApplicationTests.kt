package workshop

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.boot.test.web.client.getForEntity
import org.springframework.http.HttpStatus

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class WebAppApplicationTests(@Autowired val restTemplate: TestRestTemplate) {

	@Test
	fun `Home page loads`() {
		val entity = restTemplate.getForEntity<String>("/")
		assertThat(entity.statusCode).isEqualTo(HttpStatus.OK)
		assertThat(entity.headers["Content-Type"]?.size ?: 0).isEqualTo(1)
		val contentType = entity.headers["Content-Type"]?.first() ?: ""
		assertThat(contentType).startsWith("text/html")
		assertThat(entity.body).contains("Kotlin")
	}

}

