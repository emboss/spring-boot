package workshop;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import workshop.controllers.ApiController;
import workshop.models.json.Person;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@SpringBootTest
public class MockServerTests {

    private WebTestClient webClient;

    @BeforeEach
    public void setup() {
        webClient = WebTestClient.bindToController(new ApiController()).build();
    }

    @Test
    public void persons() {

        webClient.get().uri("/api/persons").accept(MediaType.APPLICATION_JSON)
            .exchange()
            .expectStatus().isOk()
            .expectBodyList(Person.class)
            .isEqualTo(ApiController.PERSONS);
    }

    @Test
    public void showPerson() {
        webClient.get().uri("/api/persons/{id}", 1).accept(MediaType.APPLICATION_JSON)
            .exchange()
            .expectStatus().isOk()
            .expectBody(Person.class)
            .isEqualTo(new Person(1l, "Martin", "Boßlet"));
    }
}
