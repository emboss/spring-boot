package workshop;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.FluxExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import workshop.controllers.ApiController;
import workshop.models.json.Person;
import workshop.models.json.Tick;

import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@WebFluxTest
public class WorkshopApplicationTests {

	@Autowired
	private WebTestClient webClient;

	@Test
	public void persons() {

		webClient.get().uri("/api/persons").accept(MediaType.APPLICATION_JSON)
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Person.class)
			.isEqualTo(ApiController.PERSONS);
	}

	@Test
	public void showPerson() {
		webClient.get().uri("/api/persons/{id}", 1).accept(MediaType.APPLICATION_JSON)
			.exchange()
			.expectStatus().isOk()
			.expectBody(Person.class)
			.isEqualTo(new Person(1l, "Martin", "Boßlet"));
	}

	@Test
	public void showPerson2() {
		webClient.get().uri("/api/persons/{id}", 2).accept(MediaType.APPLICATION_JSON)
			.exchange()
			.expectStatus().isOk()
			.expectBody(Person.class)
			.consumeWith(body -> {
				Person p = body.getResponseBody();
				assertEquals(p.firstName, "Marta");
			});
	}

	@Test
	public void personsWithMatcher() {
		webClient.get().uri("/api/persons")
			.exchange()
			.expectStatus().isOk()
			.expectHeader().contentType(MediaType.APPLICATION_JSON_UTF8)
			.expectBodyList(Person.class).consumeWith(result -> {
				List<Person> people = result.getResponseBody();
				assertThat(people, hasItem(new Person(1l, "Martin", "Boßlet")));
			});
	}

	@Test
	public void tickStream() {
		FluxExchangeResult<Tick> result = webClient.get().uri("/clock")
			.accept(MediaType.TEXT_EVENT_STREAM)
			.exchange()
			.expectStatus().isOk()
			.expectHeader().contentTypeCompatibleWith(MediaType.TEXT_EVENT_STREAM)
			.returnResult(Tick.class);


		StepVerifier.create(result.getResponseBody())
			.consumeNextWith(tick -> assertThat(tick.time, notNullValue()))
			.consumeNextWith(tick -> assertThat(tick.time.matches("\\d{2}:\\d{2}:\\d{2}"), is(true)))
			.thenCancel()
			.verify();
	}

	@Test
	public void stepVerifierTest() {
		Flux<String> source = Flux.just("foo", "bar")
		.concatWith(Mono.error(new IllegalArgumentException("boom")));

		StepVerifier.create(source)
			.expectNext("foo")
			.expectNext("bar")
			.expectErrorSatisfies(e -> {
				assertEquals(IllegalArgumentException.class, e.getClass());
				assertEquals("boom", e.getMessage());
			})
			.verify();
	}

}
