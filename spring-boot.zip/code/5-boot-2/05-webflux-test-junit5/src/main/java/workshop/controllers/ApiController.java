package workshop.controllers;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import workshop.models.json.Person;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RestController
public class ApiController {

    public static final List<Person> PERSONS = Arrays.asList(
        new Person(1l, "Martin", "Boßlet"),
        new Person(2l, "Marta", "Musterfrau"),
        new Person(3l, "Max", "Mustermann")
    );

    @GetMapping(value="/api/version", produces = MediaType.TEXT_PLAIN_VALUE)
    public Mono<String> version() {
        return Mono.just("1.0.0");
    }

    @GetMapping(value="/api/persons", produces = MediaType.APPLICATION_JSON_VALUE)
    public Flux<Person> persons() {
        return Flux.fromIterable(PERSONS);
    }

    @GetMapping(value="/api/persons/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<Optional<Person>> showPerson(@PathVariable Long id) {
        return Mono.just(
            PERSONS.stream().filter(p -> p.id == id).findFirst()
        );
    }

}
