package workshop.controllers;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import workshop.models.json.Tick;

import java.time.Duration;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RestController
public class ClockController {

    private static final ZoneId CET = ZoneId.of("Europe/Berlin");
    DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    @GetMapping(value = "/clock", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<Tick> clock() {
        return Flux.interval(Duration.ofSeconds(1))
        .map(
            i -> new Tick(LocalTime.now(CET).format(FORMAT))
        );
    }
}
