package workshop.models.json;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
public class Tick {

    public Tick() {}

    public Tick(String time) {
        this.time = time;
    }

    public String time;

}
