package workshop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Controller
public class HomeController {

    @GetMapping(path = "/")
    public String home() {
        return "home";
    }

}
