package spring.workshop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import spring.workshop.config.ProductionConfiguration;
import spring.workshop.config.DevelopmentConfiguration;
import spring.workshop.config.TestConfiguration;
import spring.workshop.interfaces.Exponentiator;

import java.util.stream.Stream;

public class Main {

    public static void main(String... args) {
        executeWith(createApplicationContext("test"));
        executeWith(createApplicationContext("development"));
        executeWith(createApplicationContext("production"));
    }

    private static void executeWith(ApplicationContext ctx) {
        long base = 3;
        int exponent = 4;

        System.out.println("Registered beans:");
        Stream.of(ctx.getBeanDefinitionNames()).forEach(
                bean -> System.out.println(bean)
        );
        System.out.println();

        Exponentiator service = ctx.getBean(Exponentiator.class);
        long result = service.pow(base, exponent);
        System.out.println("Computing with " + service.getClass());
        System.out.println("Result of " + base + " ^ " + exponent + ": " + result);
    }

    private static ApplicationContext createApplicationContext(String profile) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.getEnvironment().setActiveProfiles(profile);
        ctx.register(TestConfiguration.class, DevelopmentConfiguration.class, ProductionConfiguration.class);
        ctx.refresh();
        return ctx;
    }
}

