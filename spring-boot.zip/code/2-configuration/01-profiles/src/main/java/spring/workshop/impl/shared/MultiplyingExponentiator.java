package spring.workshop.impl.shared;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import spring.workshop.interfaces.Exponentiator;
import spring.workshop.interfaces.Multiplier;

import java.util.function.LongUnaryOperator;
import java.util.stream.LongStream;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Component
@Profile({ "development", "production" })
public class MultiplyingExponentiator implements Exponentiator {

    @Autowired
    private Multiplier multiplier;

    @Override
    public long pow(long base, int exponent) {
        System.out.println("Exponentiation by multiplying: " + base + " ^ " + exponent);

        return LongStream.iterate(base, LongUnaryOperator.identity())
                .limit(exponent)
                .reduce(1, (x, y) -> multiplier.multiply(x, y));
    }
}
