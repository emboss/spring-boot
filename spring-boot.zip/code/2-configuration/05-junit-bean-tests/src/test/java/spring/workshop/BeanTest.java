package spring.workshop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import spring.workshop.config.TestConfiguration;
import spring.workshop.impl.test.DefaultExponentiator;
import spring.workshop.interfaces.Exponentiator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes=TestConfiguration.class)
@ActiveProfiles("test")
public class BeanTest {

    @Autowired
    private Exponentiator exponentiator;

    @Autowired
    private TestConfiguration.TestHelper testHelper;

    @Test
    public void testExponentiator() {
        assertEquals(16, exponentiator.pow(2, 4));
    }

    @Test
    public void checkClassOfExponentiator() {
        assertTrue(exponentiator instanceof DefaultExponentiator);
    }

    @Test
    public void testTestHelper() {
        assertNotNull(testHelper.getMessage());
    }
}
