package spring.workshop.controllers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@RestController
public class IndexController {

    @Value("${app.banner}")
    private String banner;

    @GetMapping(value = { "/", "" }, produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> index() {
        return ResponseEntity.ok(banner);
    }
}
