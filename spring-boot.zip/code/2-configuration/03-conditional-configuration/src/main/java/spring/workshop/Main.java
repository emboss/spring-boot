package spring.workshop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import spring.workshop.config.AppConfiguration;

import java.util.stream.Stream;

public class Main {

    public static void main(String... args) {
        executeWith(createApplicationContext(AppConfiguration.class));

        System.setProperty("useConditionalBean", "true");
        executeWith(createApplicationContext(AppConfiguration.class));
    }

    private static void executeWith(ApplicationContext ctx) {
        System.out.println("Registered beans:");
        Stream.of(ctx.getBeanDefinitionNames()).forEach(
                name -> System.out.println(name)
        );
        System.out.println();
    }

    private static ApplicationContext createApplicationContext(Class configurationClass) {
        return new AnnotationConfigApplicationContext(configurationClass);
    }
}

