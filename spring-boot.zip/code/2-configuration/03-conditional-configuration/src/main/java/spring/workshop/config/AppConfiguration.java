package spring.workshop.config;

import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */

@Configuration
public class AppConfiguration {

    @Bean
    public Object nonConditional() {
        return new Object();
    }

    @Configuration
    @Conditional(EnvironmentCondition.class)
    public static class ConditionalConfiguration {

        @Bean
        public Object conditional() { return new Object(); }
    }


    public static class EnvironmentCondition implements Condition {

        private static final String CONDITIONAL_PROPERTY = "useConditionalBean";

        @Override
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            return context.getEnvironment().containsProperty(CONDITIONAL_PROPERTY);
        }
    }
}
