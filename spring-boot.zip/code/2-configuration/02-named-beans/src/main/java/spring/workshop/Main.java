package spring.workshop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import spring.workshop.config.AppConfiguration;
import spring.workshop.interfaces.Exponentiator;

import java.util.stream.Stream;

public class Main {

    public static void main(String... args) {
        executeWith(createApplicationContext(AppConfiguration.class));
    }

    private static void executeWith(ApplicationContext ctx) {
        long base = 3;
        int exponent = 4;

        System.out.println("Registered beans:");
        Stream.of(ctx.getBeanDefinitionNames()).forEach(
                name -> System.out.println(name)
        );
        System.out.println();

        Exponentiator service = (Exponentiator)ctx.getBean(Exponentiator.class);
        long result = service.pow(base, exponent);
        System.out.println("Computing with " + service.getClass());
        System.out.println("Result of " + base + " ^ " + exponent + ": " + result);
    }

    private static ApplicationContext createApplicationContext(Class configurationClass) {
        return new AnnotationConfigApplicationContext(configurationClass);
    }
}

