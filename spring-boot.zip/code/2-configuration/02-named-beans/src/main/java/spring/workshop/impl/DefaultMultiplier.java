package spring.workshop.impl;

import org.springframework.stereotype.Component;
import spring.workshop.interfaces.Multiplier;

/**
 * @author <a href="mailto:Martin.Bosslet@gmail.com">Martin Bosslet</a>
 */
@Component("defaultMultiplier")
public class DefaultMultiplier implements Multiplier {


    @Override
    public long multiply(long a, long b) {
        System.out.println("Default multiply: " + a + " * " + b);

        return a * b;
    }

}
